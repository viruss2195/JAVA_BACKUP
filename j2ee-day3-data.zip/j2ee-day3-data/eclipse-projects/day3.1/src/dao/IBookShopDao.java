package dao;

import java.util.List;

import pojos.Book;
import pojos.Customer;

public interface IBookShopDao {
	//validation
	Customer validateCustomer(String email, String pass) throws Exception;
	//get all distinct categories
	List<String> getAllCategories()  throws Exception;
	//get books by specific category
	List<Book> getBooksByCategory(String categoryName) throws Exception;
    //get book details by id
	Book getBookDetails(int bookId) throws Exception;
}
