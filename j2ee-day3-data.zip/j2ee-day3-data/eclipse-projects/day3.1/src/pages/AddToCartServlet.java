package pages;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class AddToCartServlet
 */
@WebServlet("/add_to_cart")
public class AddToCartServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		//get HS from WC
		HttpSession hs=request.getSession();
		//get cart from session
		ArrayList<Integer> shoppingCart=(ArrayList<Integer>)hs.getAttribute("cart");
		//get selected book ids --string ---int & populate cart
		String[] ids=request.getParameterValues("book_id");
		for(String s : ids)
			shoppingCart.add(Integer.parseInt(s));
		System.out.println("cart "+shoppingCart);
		//redirect
		response.sendRedirect("category");
	}

}
