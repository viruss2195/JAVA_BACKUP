package pages;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import pojos.Customer;

/**
 * Servlet implementation class CustomerDetailsPage
 */
@WebServlet("/details")
public class CustomerDetailsPage extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		try (PrintWriter pw = response.getWriter()) {
			
			pw.print("<h4>Login successful from 2nd page<br>");
			// retrieve cust details from request scope
			Customer c = (Customer) request.getAttribute("customer_details");
			if (c == null)
				pw.print("RD failed.....");
			else
				pw.print("Details " + c);
			pw.print("Email "+request.getParameter("em"));
		
		}
	}

}
