package beans;

import java.util.List;

import dao.BookShopDaoImpl;
import pojos.Customer;

public class BookShopBean {
	//D.M --properties --convrsational state of the clnt
	private String email,password;
	//result of B.L
	private Customer details;
	private String status;
	private BookShopDaoImpl dao;
	//def constr
	public BookShopBean() throws Exception{
		System.out.println("in JB's constr");
		//inst DAO
		dao=new BookShopDaoImpl();
	}
	//setters n getters
	public Customer getDetails() {
		return details;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	public String getStatus() {
		return status;
	}
	//B.L method --public  -- for user validation
	public String validateCustomer() throws Exception
	{
		
		//invoke dao's method
		details=dao.validateCustomer(email, password);
		//in case of success -- return "category"
				//in case of error ---"login"
		if(details == null) {
			status="Invalid Login , pls retry....";
			return "login";//dyn navigational outcome
		}
		status="Successful Login!!!!";
		return "category";
		
	}
	//B.L method for getting all categories
	public List<String> getCategories() throws Exception
	{
		return dao.getAllCategories();
	}
	

}
