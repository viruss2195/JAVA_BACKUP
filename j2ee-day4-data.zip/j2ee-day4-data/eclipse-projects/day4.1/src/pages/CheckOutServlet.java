package pages;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.BookShopDaoImpl;
import pojos.Book;
import pojos.Customer;

/**
 * Servlet implementation class CheckOutServlet
 */
@WebServlet("/check_out")
public class CheckOutServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		try (PrintWriter pw = response.getWriter()) {
			// HS
			HttpSession hs = request.getSession();
			// cust dtls n dao n cart from HS
			Customer c = (Customer) hs.getAttribute("cust_dtls");
			BookShopDaoImpl dao = (BookShopDaoImpl) hs.getAttribute("shop_dao");
			ArrayList<Integer> cart = (ArrayList<Integer>) hs.getAttribute("cart");
			if (c != null) {
				// greet user
				pw.print("<h5> Hello , " + c.getName() + "<br>");
				// invoke dao's method to get selected book details
				double total = 0;
				pw.print("Your Cart Contents<br>");
				for (int id : cart) {
					Book b = dao.getBookDetails(id);
					pw.print(b + "<br>");
					total += b.getPrice();
				}
				pw.print("Total Bill " + total + "<br>");
				pw.print("Books will be delivered shortly...");
				pw.print("You have logged out ....");

			} else
				pw.print("No session tracking....");
			//invalidate session -- HS will marked for GC
			hs.invalidate();
			pw.print("<h4><a href='index.html'>Visit Again</a></h4>");

		} catch (Exception e) {
			throw new ServletException("err in do-get of " + getClass().getName(), e);
		}

	}

}
