package pages;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.BookShopDaoImpl;
import pojos.Customer;

/**
 * Servlet implementation class LoginServlet
 */

public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private BookShopDaoImpl dao;
	
	public LoginServlet() {
		System.out.println("in def constr of "+getClass().getName()
				+" config "+getServletConfig());
	}

	@Override
	public void init() throws ServletException {
		try {
			//get servlet config
			ServletConfig config=getServletConfig();
			System.out.println("in init "+config);
			//get servlet specific init params
			String drvr=config.getInitParameter("drvr_cls");
			String url=config.getInitParameter("db_url");
			String name=config.getInitParameter("user_name");
			String pass=config.getInitParameter("user_pwd");
			dao = new BookShopDaoImpl(drvr,url,name,pass);
		} catch (Exception e) {
			throw new ServletException("err in init", e);
		}
	}

	@Override
	public void destroy() {
		if (dao != null)
			try {
				dao.cleanUp();
			} catch (Exception e) {
				throw new RuntimeException("err in destroy", e);
			}
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		try (PrintWriter pw = response.getWriter()) {
			// get HS from WC
			HttpSession hs = request.getSession();
			// save dao inst under session scope
			hs.setAttribute("shop_dao", dao);
			// read req param
			String email = request.getParameter("em");
			String pwd = request.getParameter("pass");
			// invoke dao's method for validation
			Customer c = dao.validateCustomer(email, pwd);
			// chk
			if (c == null)
				pw.print("<h4> Invalid Login , Pls <a href=login.html>Retry</a></h4>");
			else {
				//create empty cart n add it under session scope
				hs.setAttribute("cart", new ArrayList<Integer>());
				// save validated cust dtls under sesison scope
				hs.setAttribute("cust_dtls", c);
				response.sendRedirect("category");
			}
		} catch (Exception e) {
			// wrap it in SE & re-throw to WC
			throw new ServletException("err in do-get", e);
		}
	}

}
