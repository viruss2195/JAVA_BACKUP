package pages;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.BookShopDaoImpl;
import pojos.Book;

/**
 * Servlet implementation class CategoryServlet
 */
@WebServlet("/category_dtls")
public class CategoryDetailsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		try (PrintWriter pw = response.getWriter()) {
			// get HS from WC
			HttpSession hs = request.getSession();
			// get dao instance from session scope
			BookShopDaoImpl dao = (BookShopDaoImpl) hs.getAttribute("shop_dao");
			if (dao != null) {
				// read catgeory name req param
				String cat = request.getParameter("category");
				pw.print("<h5>Books under category : " + cat+"</h5>");
				// invoke dao's method to get list of books by category
				List<Book> l1 = dao.getBooksByCategory(cat);

				// dyn form generation
				pw.print("<form action='add_to_cart'>");
				// generate chkboxes dyn
				for (Book b : l1)
					pw.print("<input type=checkbox name=book_id value=" + b.getId() + ">" + b + "<br>");
				pw.print("<input type='submit' value='Add To Cart'>");
				pw.print("</form>");
			} else
				pw.print("No session tracking....");
		} catch (Exception e) {
			throw new ServletException("err in do-get of " + getClass().getName(), e);
		}
	}
}
