package dao;

import pojos.Book;
import pojos.Customer;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import static utils.DBUtils.*;

public class BookShopDaoImpl implements IBookShopDao {
	private Connection cn;
	private PreparedStatement pst1, pst3, pst4, pst5;

	public BookShopDaoImpl(String drvr,String url,String name,String pass) throws Exception {
		// get cn
		cn = fetchConnection(drvr,url,name,pass);
		pst1 = cn.prepareStatement("select * from my_customers where email=? and password=?");
		pst3 = cn.prepareStatement("select distinct category from dac_books");
		pst4 = cn.prepareStatement("select * from dac_books where category=?");
		pst5 = cn.prepareStatement("select * from dac_books where id=?");
		System.out.println("dao created...");
	}

	public void cleanUp() throws Exception {
		if (pst1 != null)
			pst1.close();
		if (pst3 != null)
			pst3.close();
		if (pst4 != null)
			pst4.close();

		if (cn != null)
			cn.close();
	}

	@Override
	public Customer validateCustomer(String email, String pass) throws Exception {
		// set IN params
		pst1.setString(1, email);
		pst1.setString(2, pass);
		// exec query
		try (ResultSet rst = pst1.executeQuery()) {
			if (rst.next())
				return new Customer(rst.getInt(1), rst.getDouble(2), email, rst.getString(4), pass, rst.getDate(6),
						rst.getString(7));
		}
		return null;
	}

	@Override
	public List<String> getAllCategories() throws Exception {
		ArrayList<String> cats = new ArrayList<>();
		try (ResultSet rst = pst3.executeQuery()) {
			while (rst.next())
				cats.add(rst.getString(1));
		}
		System.out.println("dao rets cats " + cats);
		return cats;
	}

	@Override
	public List<Book> getBooksByCategory(String categoryName) throws Exception {
		// set IN param
		pst4.setString(1, categoryName);
		// empty list
		ArrayList<Book> bks = new ArrayList<>();
		try (ResultSet rst = pst4.executeQuery()) {
			while (rst.next())
				bks.add(new Book(rst.getInt(1), rst.getString(2), rst.getString(3), categoryName, rst.getDouble(5)));
		}
		System.out.println("dao reted bks " + bks);
		return bks;
	}

	@Override
	public Book getBookDetails(int bookId) throws Exception {
		pst5.setInt(1, bookId);
		try(ResultSet rst=pst5.executeQuery())
		{
			if(rst.next())
				return new Book(bookId, rst.getString(2), rst.getString(3), rst.getString(4), rst.getDouble(5));
		}
		return null;
	}

}
