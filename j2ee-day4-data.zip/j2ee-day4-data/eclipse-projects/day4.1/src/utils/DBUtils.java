package utils;
import java.sql.*;

public class DBUtils {
//method to ret db connection
	public static Connection fetchConnection(String drvr,String url,String name,String pass) throws Exception
	{
		Class.forName(drvr);
		return DriverManager.getConnection(url,name,pass);
		/*String url="jdbc:mysql://localhost:3306/test";
		Class.forName("com.mysql.jdbc.Driver");
		return DriverManager.getConnection(url, "root", "root");*/
	}
}
