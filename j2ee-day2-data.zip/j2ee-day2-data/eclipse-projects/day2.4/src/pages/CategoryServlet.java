package pages;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.BookShopDaoImpl;
import pojos.Customer;

/**
 * Servlet implementation class CategoryServlet
 */
@WebServlet("/category")
public class CategoryServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		try (PrintWriter pw = response.getWriter()) {
			// get HS from WC
			HttpSession hs = request.getSession();
			// get customer dtls & dao instance from session scope
			Customer c = (Customer) hs.getAttribute("cust_dtls");
			BookShopDaoImpl dao = (BookShopDaoImpl) hs.getAttribute("shop_dao");
			if (c != null) {
				// hello user name
				pw.print("<h3> Hello , " + c.getName() + "</h3>");
				// invoke dao's method to get list of catgeries
				List<String> categories = dao.getAllCategories();
				// dyn form generation
				pw.print("<form action='category_dtls'>");
				pw.print("Choose Category ");
				pw.print("<select name='category'>");
				for (String s : categories)
					pw.print("<option value=" + s + ">" + s + "</option>");
				pw.print("</select>");
				pw.print("<input type='submit' value='Choose'>");
				pw.print("<input type='submit' value='Show Cart' formaction='display_cart'>");
				pw.print("</form>");
			} else
				pw.print("No session tracking....");
			pw.print("<h4><a href='check_out'>Check Out</a></h4>");
		} catch (Exception e) {
			throw new ServletException("err in do-get of " + getClass().getName(), e);
		}
	}
}
