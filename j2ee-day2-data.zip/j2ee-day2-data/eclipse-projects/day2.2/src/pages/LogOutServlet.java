package pages;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class LogOutServlet
 */
@WebServlet("/logout")
public class LogOutServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		try (PrintWriter pw = response.getWriter()) {
			Cookie[] cookies = request.getCookies();
			if (cookies != null) {
				for (Cookie c : cookies)
					if (c.getName().equals("cust_dtls")) {
						pw.print("Customer dtls from logout page " + c.getValue());
						c.setMaxAge(0);
						// add cookie to resp hdr IMPORTANT
						response.addCookie(c);
					}
			} else
				pw.print("No cookies --session tracking falied...");
			pw.print("<h5 align=center> You have successfully logged out....</h5>");
			pw.print("<h5 align=center><a href=index.html>Visit Again</a></h5>");

		}
	}

}
