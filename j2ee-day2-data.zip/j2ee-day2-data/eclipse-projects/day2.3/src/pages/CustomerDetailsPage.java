package pages;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import pojos.Customer;

/**
 * Servlet implementation class CustomerDetailsPage
 */
@WebServlet("/details")
public class CustomerDetailsPage extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		try (PrintWriter pw = response.getWriter()) {
			// get HS from WC
			HttpSession hs = request.getSession();
			System.out.println("From 2nd  page " + hs.isNew());
			System.out.println("sess id" + hs.getId());

			pw.print("<h4>Login successful..<br>");
			// retrieve cust details from HS
			Customer c = (Customer) hs.getAttribute("customer_details");
			if (c == null)
				pw.print("No session tracking --no cookies!!!!");
			else
				pw.print("Details " + c);
			pw.print("<h5 align=center><a href=logout>Log Me Out</a></h5>");

		}
	}

}
