package dao;

import pojos.Customer;

public interface IBookShopDao {
	Customer validateCustomer(String email, String pass) throws Exception;
}
